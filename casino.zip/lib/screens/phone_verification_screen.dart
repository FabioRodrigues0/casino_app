import 'package:casino_app/screens/home_screen.dart';
import 'package:casino_app/services/auth_service.dart';
import 'package:casino_app/utils/helpers.dart';
import 'package:casino_app/widgets/common/custom_button.dart';
import 'package:casino_app/widgets/common/gradient_background.dart';
import 'package:flutter/material.dart';

class PhoneVerificationScreen extends StatefulWidget {
  final String verificationId;

  PhoneVerificationScreen({required this.verificationId});

  @override
  _PhoneVerificationScreenState createState() => _PhoneVerificationScreenState();
}

class _PhoneVerificationScreenState extends State<PhoneVerificationScreen> {
  final _smsCodeController = TextEditingController();

  void _verifyCode() async {
    final smsCode = _smsCodeController.text;
    if (smsCode.length == 6) {
      await AuthService.verifyPhoneCode(widget.verificationId, smsCode);
      if (AuthService.currentUser != null) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => HomeScreen()),
        );
      } else {
        GameHelpers.showSnackBar(context, 'Código inválido. Tente novamente.');
      }
    } else {
      GameHelpers.showSnackBar(context, 'Código deve ter 6 dígitos.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GradientBackground(
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.phone_android, size: 100, color: Colors.amber),
                  SizedBox(height: 20),
                  Text(
                    'Verificação por Telefone',
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 40),
                  TextField(
                    controller: _smsCodeController,
                    keyboardType: TextInputType.number,
                    maxLength: 6,
                    decoration: InputDecoration(
                      labelText: 'Código SMS',
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.1),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                  SizedBox(height: 30),
                  CustomButton(
                    text: 'Verificar',
                    onPressed: _verifyCode,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
