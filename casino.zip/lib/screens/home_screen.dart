import 'package:flutter/material.dart';
import 'package:rive/rive.dart';

import '../services/auth_service.dart';
import '../utils/helpers.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  String _filter = 'all';

  final List<Map<String, dynamic>> rooms = [
    {
      'id': '1',
      'name': 'Slot Machine',
      'type': 'play_now',
      'riveAsset': 'assets/rive/slot_machine.riv',
      'route': '/slot',
    },
    {
      'id': '2',
      'name': 'Poker',
      'type': 'subscribe',
      'minPlayers': 4,
      'timeLimit': 300,
      'riveAsset': 'assets/rive/poker.riv',
    },
    {
      'id': '3',
      'name': 'Blackjack',
      'type': 'subscribe',
      'minPlayers': 2,
      'timeLimit': 180,
      'riveAsset': 'assets/rive/blackjack.riv',
    },
  ];

  final List<Map<String, dynamic>> filters = [
    {'icon': Icons.play_arrow, 'label': 'Jogar Agora', 'value': 'play_now'},
    {'icon': Icons.group, 'label': 'Inscrever-se', 'value': 'subscribe'},
    {'icon': Icons.all_inclusive, 'label': 'Todos', 'value': 'all'},
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    if (index == 0) {
      // Já está em Home
    } else if (index == 1) {
      // Perfil (sem tela ainda)
    } else if (index == 2) {
      // Settings (sem tela ainda)
    }
  }

  List<Map<String, dynamic>> getFilteredRooms() {
    if (_filter == 'all') return rooms;
    return rooms.where((room) => room['type'] == _filter).toList();
  }

  @override
  Widget build(BuildContext context) {
    final user = AuthService.currentUser;

    return Scaffold(
      body: Container(
        color: Color(0xFF1C2526), // Fundo sólido suave
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: EdgeInsets.all(20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Olá,',
                          style: TextStyle(color: Colors.white70, fontSize: 16),
                        ),
                        Text(
                          user?.username ?? 'Jogador',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    IconButton(
                      onPressed: () {
                        AuthService.logout();
                        Navigator.pushReplacementNamed(context, '/login');
                      },
                      icon: Icon(Icons.logout, color: Colors.white),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Container(
                  padding: EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    color: Colors.black87,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black26,
                        blurRadius: 5,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Créditos:',
                        style: TextStyle(color: Colors.white, fontSize: 18),
                      ),
                      Text(
                        '${user?.credits ?? 0}',
                        style: TextStyle(
                          color: Colors.amber,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.all(20),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: filters.map((filter) {
                      return Padding(
                        padding: EdgeInsets.only(right: 10),
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              _filter = filter['value'];
                            });
                          },
                          child: Chip(
                            avatar: Icon(filter['icon'] as IconData),
                            label: Text(
                              filter['label'],
                              style: TextStyle(color: Colors.white),
                            ),
                            backgroundColor:
                                _filter == filter['value'] ? Colors.amber : Colors.grey[800],
                            elevation: 5,
                            shadowColor: Colors.black26,
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
              Expanded(
                child: GridView.count(
                  crossAxisCount: 2,
                  crossAxisSpacing: 20,
                  mainAxisSpacing: 20,
                  padding: EdgeInsets.all(20),
                  childAspectRatio: 0.9,
                  children: getFilteredRooms().map((room) {
                    return Card(
                      color: Colors.black87,
                      elevation: 10,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                        side: BorderSide(color: Colors.amber, width: 2),
                      ),
                      child: InkWell(
                        onTap: () {
                          if (room['type'] == 'play_now') {
                            Navigator.pushNamed(context, room['route']);
                          } else {
                            _showSubscriptionDialog(room);
                          }
                        },
                        borderRadius: BorderRadius.circular(15),
                        child: Padding(
                          padding: EdgeInsets.all(15),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                height: 120,
                                child: RiveAnimation.asset(
                                  room['riveAsset'],
                                  fit: BoxFit.contain,
                                ),
                              ),
                              SizedBox(height: 15),
                              Text(
                                room['name'],
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                ),
                                textAlign: TextAlign.center,
                              ),
                              if (room['type'] == 'subscribe') ...[
                                SizedBox(height: 10),
                                Text(
                                  'Min ${room['minPlayers']} • ${room['timeLimit']}s',
                                  style: TextStyle(
                                    color: Colors.white70,
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
              BottomNavigationBar(
                items: const <BottomNavigationBarItem>[
                  BottomNavigationBarItem(
                    icon: Icon(Icons.home),
                    label: 'Home',
                  ),
                  BottomNavigationBarItem(
                    icon: Icon(Icons.person),
                    label: 'Perfil',
                  ),
                  BottomNavigationBarItem(
                    icon: Icon(Icons.settings),
                    label: 'Settings',
                  ),
                ],
                currentIndex: _selectedIndex,
                selectedItemColor: Colors.amber,
                onTap: _onItemTapped,
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showSubscriptionDialog(Map<String, dynamic> room) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.black87,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        title: Text(
          'Inscrever-se em ${room['name']}',
          style: TextStyle(color: Colors.white, fontSize: 20),
        ),
        content: Text(
          'Mínimo ${room['minPlayers']} jogadores. Tempo: ${room['timeLimit']} segundos.',
          style: TextStyle(color: Colors.white70, fontSize: 16),
        ),
        actions: [
          TextButton(
            onPressed: () {
              GameHelpers.showSnackBar(context, 'Inscrito em ${room['name']}!');
              Navigator.pop(context);
            },
            child: Text('Inscrever', style: TextStyle(color: Colors.amber, fontSize: 16)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancelar', style: TextStyle(color: Colors.white70, fontSize: 16)),
          ),
        ],
      ),
    );
  }
}
