import 'package:casino_app/screens/home_screen.dart';
import 'package:casino_app/screens/phone_verification_screen.dart';
import 'package:casino_app/screens/register_screen.dart';
import 'package:casino_app/services/auth_service.dart';
import 'package:casino_app/utils/country_codes.dart';
import 'package:casino_app/utils/helpers.dart';
import 'package:casino_app/widgets/common/custom_button.dart';
import 'package:casino_app/widgets/common/gradient_background.dart';
import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _phoneController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  String _selectedCountryCode = '+351';
  bool _useEmailPassword = false;

  void _loginWithPhone() async {
    final phoneNumber = '$_selectedCountryCode${_phoneController.text}';
    if (phoneNumber.length > 3) {
      await AuthService.loginWithPhone(
        phoneNumber,
        null,
        null,
        (verificationId, resendToken) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => PhoneVerificationScreen(verificationId: verificationId),
            ),
          );
        },
      );
    } else {
      GameHelpers.showSnackBar(context, 'Digite um número de telefone válido.');
    }
  }

  void _loginWithEmail() async {
    final email = _emailController.text;
    final password = _passwordController.text;

    if (email.isNotEmpty && password.isNotEmpty) {
      bool success = await AuthService.login(email, password);
      if (success) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => HomeScreen()),
        );
      } else {
        GameHelpers.showSnackBar(context, 'Login falhou. Verifique e-mail e senha.');
      }
    } else {
      GameHelpers.showSnackBar(context, 'Preencha todos os campos.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GradientBackground(
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.phone_android, size: 100, color: Colors.amber),
                  SizedBox(height: 20),
                  Text(
                    'Login com Telefone',
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 20),
                  Row(
                    children: [
                      DropdownButton<String>(
                        value: _selectedCountryCode,
                        items: countryCodes.map((CountryCode country) {
                          return DropdownMenuItem<String>(
                            value: country.code,
                            child: Row(
                              children: [
                                Text(country.flag),
                                SizedBox(width: 8),
                                Text(country.name),
                              ],
                            ),
                          );
                        }).toList(),
                        onChanged: (value) {
                          setState(() {
                            _selectedCountryCode = value!;
                          });
                        },
                        dropdownColor: Colors.grey[800],
                        style: TextStyle(color: Colors.white),
                        underline: Container(
                          height: 2,
                          color: Colors.amber,
                        ),
                      ),
                      Expanded(
                        child: TextField(
                          controller: _phoneController,
                          keyboardType: TextInputType.phone,
                          decoration: InputDecoration(
                            labelText: 'Número de Telefone',
                            filled: true,
                            fillColor: Colors.white.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 20),
                  CustomButton(
                    text: 'Enviar Código',
                    onPressed: _loginWithPhone,
                  ),
                  SizedBox(height: 10),
                  TextButton(
                    onPressed: () {
                      setState(() {
                        _useEmailPassword = true;
                      });
                    },
                    child: Text(
                      'Usar E-mail e Senha',
                      style: TextStyle(color: Colors.white70),
                    ),
                  ),
                  if (_useEmailPassword) ...[
                    SizedBox(height: 20),
                    TextField(
                      controller: _emailController,
                      decoration: InputDecoration(
                        labelText: 'E-mail',
                        filled: true,
                        fillColor: Colors.white.withOpacity(0.1),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                    TextField(
                      controller: _passwordController,
                      obscureText: true,
                      decoration: InputDecoration(
                        labelText: 'Senha',
                        filled: true,
                        fillColor: Colors.white.withOpacity(0.1),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                    SizedBox(height: 30),
                    CustomButton(
                      text: 'Login',
                      onPressed: _loginWithEmail,
                    ),
                    SizedBox(height: 10),
                    CustomButton(
                      text: 'Criar Conta',
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => RegisterScreen()),
                        );
                      },
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
