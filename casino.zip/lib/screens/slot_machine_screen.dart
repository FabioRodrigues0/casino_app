import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../models/game_history.dart';
import '../models/game_state.dart';
import '../models/slot_result.dart';
import '../providers/game_provider.dart';
import '../services/auth_service.dart';
import '../services/game_service.dart';
import '../utils/constants.dart';
import '../widgets/common/gradient_background.dart';
import '../widgets/slot_machine/slot_controls.dart';
import '../widgets/slot_machine/slot_header.dart' as slotHeader;
import '../widgets/slot_machine/slot_lever.dart';
import '../widgets/slot_machine/slot_reel.dart';

class SlotMachineScreen extends StatefulWidget {
  @override
  _SlotMachineScreenState createState() => _SlotMachineScreenState();
}

class _SlotMachineScreenState extends State<SlotMachineScreen> with TickerProviderStateMixin {
  late AnimationController _reel1Controller;
  late AnimationController _reel2Controller;
  late AnimationController _reel3Controller;
  late AnimationController _leverController;
  late AnimationController _coinController;

  late Animation<double> _reel1Animation;
  late Animation<double> _reel2Animation;
  late Animation<double> _reel3Animation;
  late Animation<double> _leverAnimation;
  late Animation<double> _coinAnimation;

  @override
  void initState() {
    super.initState();
    _initializeControllers();
    Provider.of<GameProvider>(context, listen: false).initializeGame();
  }

  void _initializeControllers() {
    _reel1Controller = AnimationController(
      duration: Duration(milliseconds: 100),
      vsync: this,
    );
    _reel2Controller = AnimationController(
      duration: Duration(milliseconds: 100),
      vsync: this,
    );
    _reel3Controller = AnimationController(
      duration: Duration(milliseconds: 100),
      vsync: this,
    );
    _leverController = AnimationController(
      duration: Duration(milliseconds: 300),
      vsync: this,
    );
    _coinController = AnimationController(
      duration: Duration(milliseconds: 1000),
      vsync: this,
    );

    _reel1Animation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _reel1Controller, curve: Curves.linear),
    );
    _reel2Animation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _reel2Controller, curve: Curves.linear),
    );
    _reel3Animation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _reel3Controller, curve: Curves.linear),
    );
    _leverAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _leverController, curve: Curves.elasticOut),
    );
    _coinAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _coinController, curve: Curves.bounceOut),
    );

    _setupReelListeners();
  }

  void _setupReelListeners() {
    _reel1Controller.addListener(() {
      final gameProvider = Provider.of<GameProvider>(context, listen: false);
      if (gameProvider.gameState.reelSpinning[0] && _reel1Controller.isCompleted) {
        _reel1Controller.reset();
        gameProvider.updateGameState(
          gameProvider.gameState.copyWith(
            reelPositions: [
              (gameProvider.gameState.reelPositions[0] + 1) % GameConstants.symbols.length,
              gameProvider.gameState.reelPositions[1],
              gameProvider.gameState.reelPositions[2],
            ],
          ),
        );
        if (gameProvider.gameState.reelSpinning[0]) {
          _reel1Controller.forward();
        }
      }
    });

    _reel2Controller.addListener(() {
      final gameProvider = Provider.of<GameProvider>(context, listen: false);
      if (gameProvider.gameState.reelSpinning[1] && _reel2Controller.isCompleted) {
        _reel2Controller.reset();
        gameProvider.updateGameState(
          gameProvider.gameState.copyWith(
            reelPositions: [
              gameProvider.gameState.reelPositions[0],
              (gameProvider.gameState.reelPositions[1] + 1) % GameConstants.symbols.length,
              gameProvider.gameState.reelPositions[2],
            ],
          ),
        );
        if (gameProvider.gameState.reelSpinning[1]) {
          _reel2Controller.forward();
        }
      }
    });

    _reel3Controller.addListener(() {
      final gameProvider = Provider.of<GameProvider>(context, listen: false);
      if (gameProvider.gameState.reelSpinning[2] && _reel3Controller.isCompleted) {
        _reel3Controller.reset();
        gameProvider.updateGameState(
          gameProvider.gameState.copyWith(
            reelPositions: [
              gameProvider.gameState.reelPositions[0],
              gameProvider.gameState.reelPositions[1],
              (gameProvider.gameState.reelPositions[2] + 1) % GameConstants.symbols.length,
            ],
          ),
        );
        if (gameProvider.gameState.reelSpinning[2]) {
          _reel3Controller.forward();
        }
      }
    });
  }

  @override
  void dispose() {
    _reel1Controller.dispose();
    _reel2Controller.dispose();
    _reel3Controller.dispose();
    _leverController.dispose();
    _coinController.dispose();
    super.dispose();
  }

  void _spin() async {
    final gameProvider = Provider.of<GameProvider>(context, listen: false);
    final gameState = gameProvider.gameState;

    if (gameState.isSpinning || gameState.credits < gameState.bet) return;

    HapticFeedback.mediumImpact();

    gameProvider.updateGameState(
      gameState.copyWith(
        isSpinning: true,
        credits: gameState.credits - gameState.bet,
        reelSpinning: [true, true, true],
      ),
    );

    _leverController.forward().then((_) {
      _leverController.reverse();
    });

    _reel1Controller.forward();
    _reel2Controller.forward();
    _reel3Controller.forward();

    await Future.delayed(Duration(milliseconds: 1500));
    _stopReel(0);

    await Future.delayed(Duration(milliseconds: 800));
    _stopReel(1);

    await Future.delayed(Duration(milliseconds: 800));
    _stopReel(2);

    await Future.delayed(Duration(milliseconds: 500));
    _checkResult();
  }

  void _stopReel(int reelIndex) {
    final gameProvider = Provider.of<GameProvider>(context, listen: false);
    final gameState = gameProvider.gameState;

    List<bool> newReelSpinning = List.from(gameState.reelSpinning);
    List<String> newCurrentSymbols = List.from(gameState.currentSymbols);
    List<int> newReelPositions = List.from(gameState.reelPositions);

    newReelSpinning[reelIndex] = false;
    newCurrentSymbols[reelIndex] =
        GameConstants.symbols[Random().nextInt(GameConstants.symbols.length)];
    newReelPositions[reelIndex] = GameConstants.symbols.indexOf(newCurrentSymbols[reelIndex]);

    gameProvider.updateGameState(
      gameState.copyWith(
        reelSpinning: newReelSpinning,
        currentSymbols: newCurrentSymbols,
        reelPositions: newReelPositions,
      ),
    );
  }

  void _checkResult() async {
    final gameProvider = Provider.of<GameProvider>(context, listen: false);
    final gameState = gameProvider.gameState;

    final result = GameService.calculateResult(gameState.currentSymbols, gameState.bet);

    if (result.isWin) {
      gameProvider.updateGameState(
        gameState.copyWith(
          credits: gameState.credits + result.winAmount,
        ),
      );

      AuthService.updateCredits(gameState.credits + result.winAmount);

      _coinController.forward().then((_) {
        _coinController.reverse();
      });

      HapticFeedback.heavyImpact();
      _showWinDialog(result);
    }

    await gameProvider.addGameToHistory(GameHistory(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      gameType: 'Slot Machine',
      bet: gameState.bet,
      winAmount: result.winAmount,
      isWin: result.isWin,
      symbols: gameState.currentSymbols,
      timestamp: DateTime.now(),
    ));

    gameProvider.updateGameState(
      gameState.copyWith(isSpinning: false),
    );

    _resetToIdle();
  }

  void _resetToIdle() {
    final gameProvider = Provider.of<GameProvider>(context, listen: false);
    Future.delayed(Duration(milliseconds: 2000), () {
      if (mounted) {
        gameProvider.updateGameState(
          gameProvider.gameState.copyWith(reelSpinning: [false, false, false]),
        );
        _reel1Controller.reset();
        _reel2Controller.reset();
        _reel3Controller.reset();
        _leverController.reset();
        _coinController.reset();
      }
    });
  }

  void _showWinDialog(SlotResult result) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.black87,
        title: Text('🎉 Parabéns!', style: TextStyle(color: Colors.white)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Ganhaste ${result.winAmount} créditos!',
              style: TextStyle(color: Colors.white, fontSize: 18),
            ),
            SizedBox(height: 8),
            Text(
              result.winType,
              style: TextStyle(color: Colors.amber, fontSize: 14),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Continuar', style: TextStyle(color: Colors.amber)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<GameProvider>(
      builder: (context, gameProvider, child) {
        final gameState = gameProvider.gameState;
        return Scaffold(
          body: GradientBackground(
            child: SafeArea(
              child: Column(
                children: [
                  slotHeader.SlotHeader(
                    credits: gameState.credits,
                    bet: gameState.bet,
                  ),
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _buildSlotMachine(gameState),
                        SizedBox(height: 40),
                        SlotControls(
                          bet: gameState.bet,
                          isSpinning: gameState.isSpinning,
                          credits: gameState.credits,
                          onSpin: _spin,
                          onDecreaseBet: gameProvider.decreaseBet,
                          onIncreaseBet: gameProvider.increaseBet,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildSlotMachine(GameState gameState) {
    return Container(
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.black87,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.yellow, width: 3),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              SlotReel(
                index: 0,
                animation: _reel1Animation,
                currentSymbol: gameState.currentSymbols[0],
                reelPosition: gameState.reelPositions[0],
                isSpinning: gameState.reelSpinning[0],
              ),
              SlotReel(
                index: 1,
                animation: _reel2Animation,
                currentSymbol: gameState.currentSymbols[1],
                reelPosition: gameState.reelPositions[1],
                isSpinning: gameState.reelSpinning[1],
              ),
              SlotReel(
                index: 2,
                animation: _reel3Animation,
                currentSymbol: gameState.currentSymbols[2],
                reelPosition: gameState.reelPositions[2],
                isSpinning: gameState.reelSpinning[2],
              ),
            ],
          ),
          SizedBox(height: 20),
          SlotLever(
            animation: _leverAnimation,
            onTap: _spin,
            isEnabled: !gameState.isSpinning && gameState.credits >= gameState.bet,
          ),
        ],
      ),
    );
  }
}
