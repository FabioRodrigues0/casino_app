import 'package:cloud_firestore/cloud_firestore.dart';

class User {
  final String uid;
  final String username;
  final int credits;

  User({required this.uid, required this.username, required this.credits});

  User copyWith({String? uid, String? username, int? credits}) {
    return User(
      uid: uid ?? this.uid,
      username: username ?? this.username,
      credits: credits ?? this.credits,
    );
  }

  factory User.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>? ?? {};
    print('Dados brutos do Firestore: $data'); // Depuração
    return User(
      uid: doc.id,
      username: data['username'] ?? 'Unknown',
      credits: data['credits'] ?? 0,
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'username': username,
      'credits': credits,
    };
  }
}
