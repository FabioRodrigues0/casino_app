import 'package:flutter/material.dart';

import '../models/game_history.dart';
import '../models/game_state.dart';
import '../services/auth_service.dart';
import '../services/firestore_service.dart';

class GameProvider with ChangeNotifier {
  GameState _gameState = GameState.initial();
  List<GameHistory> _gameHistory = [];

  GameState get gameState => _gameState;
  List<GameHistory> get gameHistory => _gameHistory;

  void initializeGame() async {
    if (AuthService.currentUser != null) {
      final storedCredits = (await FirestoreService.getUser(AuthService.uid!))?.credits ?? 100;
      _gameState = _gameState.copyWith(credits: storedCredits);
      notifyListeners();
    }

    // Simulação de histórico (a implementar no Firestore)
    notifyListeners();
  }

  void updateGameState(GameState newState) {
    _gameState = newState;
    if (AuthService.currentUser != null) {
      FirestoreService.updateCredits(AuthService.uid!, newState.credits);
    }
    notifyListeners();
  }

  Future<void> addGameToHistory(GameHistory game) async {
    _gameHistory.add(game);
    // Implementar salvamento no Firestore (ex.: coleção 'gameHistory')
    notifyListeners();
  }

  void decreaseBet() {
    if (_gameState.bet > 1) {
      _gameState = _gameState.copyWith(bet: _gameState.bet - 1);
      notifyListeners();
    }
  }

  void increaseBet() {
    if (_gameState.bet < _gameState.credits) {
      _gameState = _gameState.copyWith(bet: _gameState.bet + 1);
      notifyListeners();
    }
  }
}
