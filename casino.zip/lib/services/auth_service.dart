import 'package:casino_app/models/user.dart' as myUser;
import 'package:firebase_auth/firebase_auth.dart';

import 'firestore_service.dart';

class AuthService {
  static final FirebaseAuth _auth = FirebaseAuth.instance;
  static myUser.User? _currentUser;

  static myUser.User? get currentUser => _currentUser;

  static Stream<User?> get authStateChanges => _auth.authStateChanges();

  static Future<bool> login(String email, String password) async {
    try {
      await _auth.setSettings(appVerificationDisabledForTesting: true);
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      print('Login bem-sucedido para $email. UserCredential: $userCredential');
      await _loadUserData(userCredential.user!.uid);
      return true;
    } catch (e) {
      print('Erro no login: $e');
      _currentUser = null;
      return false;
    }
  }

  static Future<void> _loadUserData(String uid) async {
    try {
      _currentUser = await FirestoreService.getUser(uid);
      if (_currentUser == null) {
        print('Usuário não encontrado no Firestore para UID: $uid');
      } else {
        print('Usuário carregado do Firestore: $_currentUser');
      }
    } catch (e) {
      print('Erro ao carregar dados do usuário: $e');
      _currentUser = null;
    }
  }

  static Future<void> loadUserData() async {
    if (_auth.currentUser != null) {
      await _loadUserData(_auth.currentUser!.uid);
    }
  }

  static Future<void> register(String email, String password) async {
    try {
      await _auth.setSettings(appVerificationDisabledForTesting: true);
      UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      await FirestoreService.saveUser(userCredential.user!.uid,
          myUser.User(uid: userCredential.user!.uid, username: email.split('@')[0], credits: 100));
      await _loadUserData(userCredential.user!.uid);
    } catch (e) {
      print('Erro no registro: $e');
      _currentUser = null;
    }
  }

  static Future<void> loginWithPhone(String phoneNumber,
      [Function(PhoneAuthCredential)? verificationCompleted,
      Function(FirebaseAuthException)? verificationFailed,
      Function(String, int?)? codeSent,
      Function(String)? codeAutoRetrievalTimeout]) async {
    try {
      await _auth.setSettings(appVerificationDisabledForTesting: true);
      await _auth.verifyPhoneNumber(
        phoneNumber: phoneNumber,
        verificationCompleted: verificationCompleted ??
            (PhoneAuthCredential credential) async {
              UserCredential userCredential = await _auth.signInWithCredential(credential);
              await _loadUserData(userCredential.user!.uid);
            },
        verificationFailed: verificationFailed ??
            (FirebaseAuthException e) {
              print('Erro na verificação: $e');
            },
        codeSent: codeSent ??
            (String verificationId, int? resendToken) {
              print('Código enviado para $phoneNumber. Verification ID: $verificationId');
            },
        codeAutoRetrievalTimeout: codeAutoRetrievalTimeout ??
            (String verificationId) {
              print('Tempo de recuperação automática expirou. Verification ID: $verificationId');
            },
      );
    } catch (e) {
      print('Erro no login com telefone: $e');
    }
  }

  static Future<void> verifyPhoneCode(String verificationId, String smsCode) async {
    try {
      PhoneAuthCredential credential =
          PhoneAuthProvider.credential(verificationId: verificationId, smsCode: smsCode);
      UserCredential userCredential = await _auth.signInWithCredential(credential);
      await _loadUserData(userCredential.user!.uid);
    } catch (e) {
      print('Erro ao verificar código: $e');
    }
  }

  static Future<void> saveUser(myUser.User user) async {
    if (_currentUser != null) {
      await FirestoreService.saveUser(_currentUser!.uid, user);
    }
  }

  static Future<void> updateCredits(int credits) async {
    if (_currentUser != null) {
      _currentUser = _currentUser!.copyWith(credits: credits);
      await FirestoreService.updateCredits(_currentUser!.uid, credits);
    }
  }

  static Future<void> logout() async {
    await _auth.signOut();
    _currentUser = null;
  }

  static String? get uid => _currentUser?.uid;
}
