import 'package:casino_app/models/user.dart' as myUser;
import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  static final FirebaseFirestore _db = FirebaseFirestore.instance;

  static Future<myUser.User?> getUser(String uid) async {
    try {
      DocumentSnapshot doc = await _db.collection('users').doc(uid).get();
      if (doc.exists) {
        final data = doc.data();
        print(
            'Dados brutos do Firestore para $uid (tipo: ${data.runtimeType}): $data'); // Depuração detalhada
        if (data is Map<String, dynamic>) {
          return myUser.User.fromFirestore(doc);
        } else {
          print('Dados inesperados (não é Map): $data');
          return null;
        }
      }
      print('Documento não encontrado para UID: $uid');
      return null;
    } catch (e) {
      print('Erro ao buscar usuário: $e');
      return null;
    }
  }

  static Future<void> saveUser(String uid, myUser.User user) async {
    try {
      await _db.collection('users').doc(uid).set(user.toFirestore());
    } catch (e) {
      print('Erro ao salvar usuário: $e');
    }
  }

  static Future<void> updateCredits(String uid, int credits) async {
    try {
      await _db.collection('users').doc(uid).update({'credits': credits});
    } catch (e) {
      print('Erro ao atualizar créditos: $e');
    }
  }
}
