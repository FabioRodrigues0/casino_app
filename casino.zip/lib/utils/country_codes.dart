class CountryCode {
  final String code;
  final String name;
  final String flag;

  CountryCode(this.code, this.name, this.flag);
}

final List<CountryCode> countryCodes = [
  CountryCode('+351', 'Portugal', '🇵🇹'),
  CountryCode('+55', 'Brasil', '🇧🇷'),
];
